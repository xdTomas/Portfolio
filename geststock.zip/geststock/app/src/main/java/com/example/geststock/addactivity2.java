package com.example.geststock;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.chip.Chip;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class addactivity2 extends AppCompatActivity {

    private Button cancelbutton;
    private EditText product;
    private Button addButton;
    private Chip checkchip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addactivity2);


        //bind views
        cancelbutton = (Button) findViewById(R.id.btn_cancelar);
        product = (EditText) findViewById(R.id.txt_product);
        addButton = (Button) findViewById(R.id.btn_confirm);
        checkchip = (Chip) findViewById(R.id.chip);


        //listener
        cancelbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(addactivity2.this, ProductListActivity.class);
                startActivity(intent);
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String produto = product.getText().toString();
                Boolean check = checkchip.isChecked();

                if (produto.isEmpty()){
                    product.setError("Campo vazio");
                    return;
                }
                // add BD
                addproducttoBD(produto, check);

            }
        });
    }

    private void addproducttoBD(String produto, Boolean check) {

        HashMap<String, Object> map = new HashMap<>();
        map.put("produto", produto);
        map.put("verifica", check);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myref = database.getReference("produtos");

        String key = myref.push().getKey();
        map.put("key", key);

        myref.child(key).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                Toast.makeText(addactivity2.this, "Sucesso", Toast.LENGTH_SHORT).show();
                product.getText().clear();
            }
        });
    }
}