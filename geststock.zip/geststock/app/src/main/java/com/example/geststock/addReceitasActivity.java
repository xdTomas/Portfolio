package com.example.geststock;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class addReceitasActivity extends AppCompatActivity {

    private Button cancelbutton;
    private EditText product;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_receitas);

        cancelbutton = (Button) findViewById(R.id.btn_cancelar);
        product = (EditText) findViewById(R.id.txt_product);
        addButton = (Button) findViewById(R.id.btn_confirm);

        cancelbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(addReceitasActivity.this, receitasActivity.class);
                startActivity(intent);
            }
        });



    }
}