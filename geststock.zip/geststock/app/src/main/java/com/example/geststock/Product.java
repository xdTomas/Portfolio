package com.example.geststock;

public class Product {
    private String produto;
    private boolean verifica;
    private String key; // Adicione a propriedade para armazenar a chave

    public Product() {
        // Constructor vazio necessário para Firebase
    }

    public Product(String produto, boolean verifica) {
        this.produto = produto;
        this.verifica = verifica;
    }

    // Getters e Setters para as propriedades

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public boolean isVerifica() {
        return verifica;
    }

    public void setVerifica(boolean verifica) {
        this.verifica = verifica;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}

