package com.example.geststock;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private Context context;

    public ProductAdapter(List<Product> productList, Context context) {
        this.productList = productList;
        this.context = context;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_product, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);
        holder.productName.setText(product.getProduto());
        holder.productCheck.setChecked(product.isVerifica());

        holder.productCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Show confirmation dialog
                new AlertDialog.Builder(context)
                        .setTitle("Confirmar alteração")
                        .setMessage("Tem a certeza que deseja alterar o estado do produto?")
                        .setPositiveButton("Sim", (dialog, which) -> {
                            // Update the product status in Firebase
                            DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("produtos").child(product.getKey());
                            myRef.child("verifica").setValue(isChecked);
                            Toast.makeText(context, "Estado do produto alterado", Toast.LENGTH_SHORT).show();
                        })
                        .setNegativeButton("Não", (dialog, which) -> {
                            holder.productCheck.setOnCheckedChangeListener(null); // Remove listener temporarily
                            holder.productCheck.setChecked(!isChecked); // Invert the checkbox state
                            holder.productCheck.setOnCheckedChangeListener(this); // Add back listener
                        })
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        TextView productName;
        CheckBox productCheck;

        public ProductViewHolder(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.product_name);
            productCheck = itemView.findViewById(R.id.product_check);
        }
    }
}


